package id.haadii.moviecatalogueapi.repository

class EndPoint {
    companion object {
        const val MOVIE_URL = "https://api.themoviedb.org/3/discover/movie?api_key=bf7aeefaca5f62fcc1c1b20edad484a9&language=en-US"
        const val TV_SHOW_URL = "https://api.themoviedb.org/3/discover/tv?api_key=bf7aeefaca5f62fcc1c1b20edad484a9&language=en-US"
        const val URL = "https://image.tmdb.org/t/p/w185/"
    }
}